# Architecture: Deck Slide → Code Mapping

This document maps each concept from the `Robotics_and_Automation_Project_1`
slide deck to the exact file/function that implements it.

| Deck slide | Concept | Implementation |
|---|---|---|
| "The Arrow of Causality: Kinematic Formulations" | Forward Kinematics (deterministic, one solution) | `src/kinematics/forward_kinematics.py::forward_kinematics` |
| "The Arrow of Causality: Kinematic Formulations" | Inverse Kinematics (non-linear, may need iterative approximation) | `src/kinematics/inverse_kinematics.py::solve_ik` |
| "Establishing the Input Goal" — Target Pose (SE(3)) | Homogeneous transform target `[R p; 0 1]` | `forward_kinematics` returns this exact 4x4 form |
| "Establishing the Input Goal" — Transform Tree (TF2) | Coordinate frame chain, base_link → shoulder_link → end_effector | `src/kinematics/forward_kinematics.py::joint_transforms`; real TF2 broadcast happens in `ros2_ws/arm_controller/urdf/six_axis_arm.urdf.xacro` + `robot_state_publisher` |
| "The Local Minima Trap" — det(J(q)) → 0, joint limit clamping | Damped least-squares to stay well-conditioned near singularities; **soft** limit repulsion instead of hard clamp | `inverse_kinematics.py::solve_ik` (see the `limit_margin` / soft-repulsion block, and the `damping` parameter in the DLS step) |
| "Solver Diagnostic Matrix" — Orocos-KDL / IKFast / TRAC-IK | Family of IK solver strategies (numerical gradient vs analytic vs hybrid) | `solve_ik` implements the damped-least-squares family (closest to Orocos-KDL / TRAC-IK's numeric component); an analytic/IKFast-style closed-form solver is listed as a future extension in the README |
| "Collision Avoidance and Scene Monitoring" — FCL, State Validity, Self-Collision | Capsule/segment vs. sphere obstacle checks; coarse self-collision | `src/planning/collision.py::check_link_collisions`, `check_self_collision` |
| "The Output Stage: Compiling the Action" — `control_msgs/action/FollowJointTrajectory` | Time-parameterized position/velocity/acceleration waypoints | `src/planning/trajectory.py::generate_joint_trajectory` / `generate_cartesian_guided_trajectory`; real action goal construction in `ros2_ws/arm_controller/arm_controller/ik_planning_node.py::_send_trajectory` |
| "The Middleware Abstraction Layer: ROS 2" — Topics / Services / Action Servers | Communication pattern between planning node, hardware drivers, state publishers | Modeled in `ik_planning_node.py`: `/joint_states` subscription (Topic), `/arm_controller/follow_joint_trajectory` (Action Server) |
| "The Split-Reality Mirror" — RViz (kinematic intent) vs Gazebo (physical reality) | Two digital twins: what the robot thinks vs. what it will actually do | Pure-Python `plot_scene` (`src/utils/visualization.py`) stands in for RViz's kinematic view; the `ros2_ws` package's `gazebo_ros_control` plugin in the URDF stands in for Gazebo physics |
| "Hardware Interfaces and Transmissions" — URDF `<transmission>` / `<hardwareInterface>` | Mapping joint-space commands to simulated actuators | `ros2_ws/arm_controller/urdf/six_axis_arm.urdf.xacro` (`transmission_block` macro) |
| "Dynamic Tuning Failure Modes" — PID under/over-tuning | Not simulated physically in the pure-Python demo (no dynamics/torque model); flagged as a real concern for the Gazebo deployment | Documented here and in README as a known gap / extension |
| "Beyond the Basics: Safe Hardware Coordination" — interdependent trajectory locking, emergency stop | Multi-actuator resource locking | Out of scope for Project 1's single-arm demo; would be added as a `lifecycle`/state-machine layer around `ik_planning_node.py` in a real multi-device cell |
| "Synthesis: The Production-Grade Node" | Full wiring: Python/C++ node → IK solver → TF2 → FCL → gazebo_ros_control | `ros2_ws/arm_controller/arm_controller/ik_planning_node.py` — mirrors this diagram directly, reusing `src/kinematics` and `src/planning` from the pure-Python core |

## Known simplifications (and why)

1. **Numeric Jacobian instead of analytic.** The deck contrasts
   numeric (Orocos-KDL, slow/robust) vs. analytic (IKFast,
   fast/rigid) vs. hybrid (TRAC-IK) solvers. This project uses a
   numeric damped-least-squares solver because it works for *any* DH
   chain without deriving closed-form equations — the right choice for
   a teaching/demo repo. A production system would likely swap in an
   IKFast-generated solver for this specific arm geometry.
2. **Sphere/capsule collision, not full mesh FCL.** Real MoveIt/FCL
   checks exact link meshes. Spheres and capsules are a deliberate
   simplification that keeps the whole pipeline dependency-free
   (numpy only) while still demonstrating the same architecture
   (discretize trajectory → validate every waypoint → abort on
   violation).
3. **No dynamics/torque simulation.** The "Dynamic Tuning Failure
   Modes" slide (PID gains, gravity, torque) requires an actual physics
   engine (Gazebo). The pure-Python demo only checks kinematic/geometric
   collision, not whether a real motor could track the trajectory under
   load — that's exactly what the `ros2_ws` + Gazebo half of this
   project is for.
