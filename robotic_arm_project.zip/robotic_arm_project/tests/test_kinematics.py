"""
Basic sanity tests for the kinematics and planning modules.
Run with:  python3 -m pytest tests/ -v
(or python3 tests/test_kinematics.py to run standalone)
"""

import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.kinematics.forward_kinematics import forward_kinematics, link_positions
from src.kinematics.inverse_kinematics import solve_ik
from src.kinematics.dh_params import NUM_JOINTS, JOINT_LIMITS
from src.planning.collision import SphereObstacle, check_link_collisions


def test_fk_zero_pose_reachable():
    q0 = np.zeros(NUM_JOINTS)
    T = forward_kinematics(q0)
    assert T.shape == (4, 4)
    # Homogeneous transform bottom row must be [0,0,0,1]
    assert np.allclose(T[3], [0, 0, 0, 1])


def test_ik_round_trip_matches_fk():
    """IK solution, fed back through FK, should reproduce the target position."""
    target = np.array([0.45021, -0.12055, 0.31000])
    result = solve_ik(target_position=target)
    assert result.success, f"IK did not converge: {result.message}"
    achieved = forward_kinematics(result.q)[:3, 3]
    assert np.linalg.norm(achieved - target) < 1e-3, (
        f"FK(IK(target)) = {achieved}, expected {target}"
    )


def test_ik_respects_joint_limits():
    target = np.array([0.45021, -0.12055, 0.31000])
    result = solve_ik(target_position=target)
    for qi, (lo, hi) in zip(result.q, JOINT_LIMITS):
        assert lo - 1e-6 <= qi <= hi + 1e-6, f"Joint value {qi} outside limits ({lo}, {hi})"


def test_link_positions_length():
    q = np.zeros(NUM_JOINTS)
    pts = link_positions(q)
    assert pts.shape == (NUM_JOINTS + 1, 3)


def test_collision_detects_intersecting_sphere():
    q = np.zeros(NUM_JOINTS)
    pts = link_positions(q)
    # Put an obstacle exactly on a known link midpoint
    mid = (pts[1] + pts[2]) / 2.0
    obstacle = SphereObstacle(center=mid, radius=0.1, name="test_obstacle")
    hits = check_link_collisions(pts, [obstacle], link_radius=0.03)
    assert len(hits) > 0, "Expected a collision to be detected"


def test_collision_clear_for_far_obstacle():
    q = np.zeros(NUM_JOINTS)
    pts = link_positions(q)
    far_obstacle = SphereObstacle(center=np.array([5.0, 5.0, 5.0]), radius=0.1, name="far_away")
    hits = check_link_collisions(pts, [far_obstacle], link_radius=0.03)
    assert len(hits) == 0, "Did not expect a collision for a far-away obstacle"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    passed, failed = 0, 0
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL: {t.__name__} -> {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
