# Project 1: Robotic Arm Kinematics & Path Planning

DecodeLabs Industrial Training Kit — Batch 2026

This repository implements the exact scenario from the training deck:
> *Program a simulated 6-axis robotic arm to move accurately from Point A
> to Point B without colliding with its environment, using Inverse
> Kinematics, ROS-style collision checking, and a smooth trajectory
> spline.*

## What's actually runnable here

This repo ships **two things**:

1. **`src/` — a fully working, pure-Python simulation** (numpy/scipy/matplotlib
   only). This is the part you can run right now, with no ROS/Gazebo
   install, and it implements the real math: DH-based forward kinematics,
   a damped least-squares inverse-kinematics solver, capsule-vs-sphere
   collision checking, and a collision-checked trajectory planner with
   automatic re-routing.
2. **`ros2_ws/arm_controller/` — a ROS 2 (ament_python) package stub**
   that wires the *same* kinematics/planning code into a real
   `rclpy` node, URDF, and launch file, so you can drop it into an
   actual ROS 2 + Gazebo workspace later. It reuses `src/` directly —
   see [Running the ROS 2 package](#running-the-ros-2-package-in-a-real-workspace)
   below.

> ROS 2 and Gazebo are not installed in the environment that generated
> this repo (no GUI, no ROS apt packages, restricted network), so the
> `ros2_ws/` package cannot be executed here — only the pure-Python
> simulation was actually run to produce the results below. The ROS 2
> package is provided as a correct, ready-to-build reference
> implementation for when you have a real ROS 2 workspace available.

## Quick start

```bash
git clone <this-repo>
cd robotic_arm_project
pip install -r requirements.txt
python3 -m src.simulate
```

This will:
1. Define **Point A** and **Point B** (Point B is the exact target
   coordinate from the deck's dashboard slide: `X:+450.21mm Y:-120.55mm Z:+310.00mm`)
2. Solve **Inverse Kinematics** for both points (damped least-squares /
   Jacobian method — same family as Orocos-KDL / TRAC-IK)
3. Run a **static collision check** at both postures
4. Attempt a **direct joint-space trajectory** — this collides with two
   obstacles placed in the workspace, triggering a `TRAJECTORY ABORT`
   (mirroring the deck's collision-avoidance slide)
5. **Re-plan** automatically: a lift-traverse-lower reroute is found
   that is fully collision-free
6. Save two plots to `outputs/`:
   - `scene.png` — 3D render of start/goal arm poses, obstacles, and
     the end-effector path
   - `joint_profiles.png` — position/velocity/acceleration curves for
     all 6 joints (the `FollowJointTrajectory`-equivalent output)

### Run the tests

```bash
python3 -m pytest tests/ -v
# or, without pytest:
python3 tests/test_kinematics.py
```

Tests cover: FK sanity, IK/FK round-trip accuracy, joint-limit
compliance, and collision detection (both hit and clear cases).

## Project layout

```
robotic_arm_project/
├── requirements.txt
├── README.md
├── src/
│   ├── simulate.py                  # main entry point — run this
│   ├── kinematics/
│   │   ├── dh_params.py             # DH table + joint limits
│   │   ├── forward_kinematics.py    # FK: q -> end-effector pose
│   │   └── inverse_kinematics.py    # IK: target pose -> q (damped least squares)
│   ├── planning/
│   │   ├── collision.py             # capsule-vs-sphere collision checks
│   │   ├── trajectory.py            # quintic + Cartesian-guided trajectory generation
│   │   └── planner.py               # direct-path attempt + automatic reroute
│   └── utils/
│       └── visualization.py         # 3D scene + joint profile plots
├── tests/
│   └── test_kinematics.py
├── outputs/                         # generated plots land here
├── docs/
│   └── architecture.md              # how each module maps to the deck's slides
└── ros2_ws/arm_controller/          # real ROS 2 package stub (see below)
```

## Sample output

```
--- Inverse Kinematics ---
IK for Point A: success=True, iters=9, final_error=0.000071 m
IK for Point B: success=True, iters=5, final_error=0.000013 m
  FK(IK(Point B)) = [0.4502 -0.12055 0.30999] (target was [0.45021 -0.12055 0.31])

--- Static Collision Check ---
Point A pose: clear
Point B pose: clear

--- Trajectory Generation (A -> B) ---
Planner attempts: 2
Planner message:  Direct path collided; re-planned via a lift-traverse-lower
                  reroute (+0.15 m clearance above start/goal) is collision-free.
Trajectory collision-free: True
TRAJECTORY ABORT check: none triggered. Path is clear for execution.
Peak joint velocity:     0.503 rad/s
Peak joint acceleration: 3.617 rad/s^2
```

## Design notes / how this maps to the deck

See [`docs/architecture.md`](docs/architecture.md) for a slide-by-slide
mapping, but briefly:

- **Forward Kinematics** (`forward_kinematics.py`): deterministic DH-chain
  multiplication — always one unique solution, as described in "The Arrow
  of Causality" slide.
- **Inverse Kinematics** (`inverse_kinematics.py`): damped least-squares
  (Levenberg-Marquardt-style) numeric solver. Uses a **soft** joint-limit
  repulsion instead of hard clamping near boundaries, specifically to
  avoid the "Local Minima Trap" the deck calls out — hard clamping can
  zero out the search direction and strand the solver.
- **Collision checking** (`collision.py`): links are approximated as
  capsules (segment + radius) and obstacles as spheres — a lightweight
  stand-in for FCL (Flexible Collision Library), which is what MoveIt
  actually uses under the hood.
- **Trajectory generation** (`trajectory.py`): quintic polynomials give
  zero velocity/acceleration at both ends (smooth start/stop, matching
  `control_msgs/action/FollowJointTrajectory`). For multi-waypoint
  reroutes, a single clamped cubic spline is fit across *all* waypoints
  (rather than stitching independent zero-velocity segments) to avoid a
  jerky stop-start motion at each via-point.
- **Path re-planning** (`planner.py`): if the direct path collides, tries
  a "lift above start → traverse above the obstacle field → lower onto
  goal" Cartesian path, solving IK at closely-spaced waypoints each
  seeded from the previous solution — this keeps the arm's
  elbow/wrist configuration continuous instead of jumping between two
  independently-seeded IK solutions (which is what caused the
  first, naive joint-space-only reroute attempts to still clip the
  obstacles during development of this project).

## Running the ROS 2 package (in a real workspace)

The `ros2_ws/arm_controller/` package is a real `ament_python` ROS 2
package. To use it on a machine with ROS 2 (Humble or Jazzy) and Gazebo
installed:

```bash
# 1. Copy (or symlink) this whole repo somewhere ROS 2 can see both
#    the `src/` kinematics core and the ROS package, e.g.:
mkdir -p ~/ros2_ws/src
cp -r robotic_arm_project ~/ros2_ws/src/robotic_arm_project
ln -s ~/ros2_ws/src/robotic_arm_project/ros2_ws/arm_controller ~/ros2_ws/src/arm_controller

# 2. Install ROS dependencies
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y

# 3. Build
colcon build --packages-select arm_controller
source install/setup.bash

# 4. Launch (robot_state_publisher + RViz + the IK planning node)
ros2 launch arm_controller arm_bringup.launch.py
```

The node `ik_planning_node.py` imports directly from `src/kinematics`
and `src/planning` (the same modules exercised by `python3 -m
src.simulate`), solves IK for a target pose, generates a
collision-checked trajectory, and sends it as a
`control_msgs/action/FollowJointTrajectory` goal — matching the
"Synthesis: The Production-Grade Node" architecture diagram in the deck.

## Extending this project (per the deck's "Conclusion" slide)

Ideas for going further, as the deck suggests — treat every
`TRAJECTORY ABORT` as a learning opportunity, not a dead end:

- Swap the quintic per-joint spline for a true minimum-jerk or
  time-optimal (TOPP-RA style) time parameterization
- Add dynamic (moving) obstacles and re-plan online
- Replace the numeric Jacobian IK with an analytic/closed-form solver
  (e.g. IKFast-style) for the specific DH chain used here
- Add proper orientation control at the via-points (currently the
  reroute only targets position, not full SE(3) pose)
- Port the obstacle scene into an actual MoveIt `PlanningSceneInterface`
  and swap the toy collision checker for real FCL calls
