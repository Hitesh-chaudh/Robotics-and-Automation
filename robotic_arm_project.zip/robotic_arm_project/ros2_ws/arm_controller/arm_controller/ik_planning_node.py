"""
ik_planning_node.py

ROS 2 node implementing the "Synthesis: The Production-Grade Node"
architecture from the deck:

    Python/C++ Node (action client request)
        -> TRAC-IK-style solver (here: the damped-least-squares solver
           from src/kinematics/inverse_kinematics.py)
        -> TF2 Transform Tree (space)
        -> FCL Collision Scene (safety) (here: src/planning/collision.py)
        -> gazebo_ros_control (physics), via a
           control_msgs/action/FollowJointTrajectory goal

This node re-uses the exact same kinematics/planning code validated in
the standalone Python simulation (src/simulate.py) so the "digital
brain" is identical whether it is exercised in the pure-Python demo or
wired into a real ROS 2 + Gazebo stack.

NOTE: This file requires a real ROS 2 (rclpy, control_msgs, tf2_ros)
installation and cannot run inside this sandbox. See README.md for how
to build and run it in an actual ROS 2 workspace.
"""

import sys
import os

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from sensor_msgs.msg import JointState
from builtin_interfaces.msg import Duration
import tf2_ros

# The project's pure-Python kinematics/planning core (same code used by
# src/simulate.py) is vendored alongside this ROS package so both the
# standalone demo and the real ROS 2 node share one implementation.
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from src.kinematics.dh_params import NUM_JOINTS
from src.kinematics.inverse_kinematics import solve_ik
from src.planning.collision import SphereObstacle
from src.planning.planner import plan_collision_free_path

JOINT_NAMES = [f"joint_{i+1}" for i in range(NUM_JOINTS)]


class IKPlanningNode(Node):
    def __init__(self):
        super().__init__("ik_planning_node")

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self._current_joint_state = None
        self.create_subscription(JointState, "/joint_states", self._on_joint_state, 10)

        self._action_client = ActionClient(
            self, FollowJointTrajectory, "/arm_controller/follow_joint_trajectory"
        )

        # Obstacle scene — in a full system this would come from a
        # perception node populating the MoveIt planning scene; here we
        # mirror the static demo scene from src/simulate.py.
        self.obstacles = [
            SphereObstacle(center=np.array([0.35941, 0.10343, 0.36440]), radius=0.036, name="obstacle_1"),
            SphereObstacle(center=np.array([0.38869, 0.03120, 0.34686]), radius=0.035, name="obstacle_2"),
        ]

        self.get_logger().info("IK planning node ready. Call plan_and_execute(target_xyz) to move.")

    def _on_joint_state(self, msg: JointState):
        self._current_joint_state = msg

    def _current_q(self) -> np.ndarray:
        if self._current_joint_state is None:
            return np.zeros(NUM_JOINTS)
        name_to_pos = dict(zip(self._current_joint_state.name, self._current_joint_state.position))
        return np.array([name_to_pos.get(n, 0.0) for n in JOINT_NAMES])

    def plan_and_execute(self, target_xyz: np.ndarray, start_xyz: np.ndarray = None):
        """Solve IK for target_xyz, plan a collision-checked trajectory, and send it."""
        q_start = self._current_q()
        if start_xyz is None:
            start_xyz = target_xyz  # only used by the planner's reroute heuristic

        ik_result = solve_ik(target_position=target_xyz, q_init=q_start)
        if not ik_result.success:
            self.get_logger().error(f"IK failed to converge: {ik_result.message}")
            return

        plan = plan_collision_free_path(
            q_start=q_start, point_start_xyz=start_xyz,
            point_goal_xyz=target_xyz, q_goal=ik_result.q,
            obstacles=self.obstacles,
        )

        if not plan.trajectory.collision_free:
            self.get_logger().error(
                "TRAJECTORY ABORT: no collision-free path found. "
                f"Report: {plan.trajectory.collision_report[:3]}"
            )
            return

        self._send_trajectory(plan.trajectory)

    def _send_trajectory(self, traj):
        if not self._action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("FollowJointTrajectory action server not available.")
            return

        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES
        for k in range(len(traj.t)):
            point = JointTrajectoryPoint()
            point.positions = traj.q[k].tolist()
            point.velocities = traj.qd[k].tolist()
            point.accelerations = traj.qdd[k].tolist()
            sec = int(traj.t[k])
            nanosec = int((traj.t[k] - sec) * 1e9)
            point.time_from_start = Duration(sec=sec, nanosec=nanosec)
            goal.trajectory.points.append(point)

        self.get_logger().info(
            f"Sending FollowJointTrajectory goal with {len(goal.trajectory.points)} waypoints "
            f"over {traj.t[-1]:.2f}s."
        )
        send_goal_future = self._action_client.send_goal_async(goal)
        send_goal_future.add_done_callback(self._on_goal_response)

    def _on_goal_response(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Trajectory goal rejected.")
            return
        self.get_logger().info("Trajectory goal accepted; executing.")
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(
            lambda f: self.get_logger().info(f"Execution finished: {f.result().result}")
        )


def main(args=None):
    rclpy.init(args=args)
    node = IKPlanningNode()

    # Example: move to the deck's target coordinate
    # (X:+450.21mm, Y:-120.55mm, Z:+310.00mm)
    target = np.array([0.45021, -0.12055, 0.31000])
    node.plan_and_execute(target_xyz=target)

    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
