from setuptools import setup
import os
from glob import glob

package_name = "arm_controller"

setup(
    name=package_name,
    version="1.0.0",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        (os.path.join("share", package_name, "launch"), glob("launch/*.launch.py")),
        (os.path.join("share", package_name, "urdf"), glob("urdf/*.xacro")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="DecodeLabs",
    maintainer_email="decodelabs.tech@gmail.com",
    description="Project 1: Robotic Arm Kinematics & Path Planning (IK + collision-checked trajectories).",
    license="MIT",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "ik_planning_node = arm_controller.ik_planning_node:main",
        ],
    },
)
