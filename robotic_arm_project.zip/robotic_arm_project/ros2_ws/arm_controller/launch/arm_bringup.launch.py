"""
arm_bringup.launch.py

Brings up:
  - robot_state_publisher (publishes TF2 transform tree from the URDF,
    the "Transform Tree (TF2)" from the deck)
  - RViz2 (kinematic-intent view — "RViz (Kinematic Intent)" slide)
  - the ik_planning_node (this package) which computes IK + a
    collision-checked trajectory and sends a FollowJointTrajectory
    action goal

Run (inside a real ROS 2 Humble/Jazzy workspace, after colcon build):
    ros2 launch arm_controller arm_bringup.launch.py
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory("arm_controller")
    urdf_xacro_path = os.path.join(pkg_share, "urdf", "six_axis_arm.urdf.xacro")

    robot_description = ExecuteProcess(
        cmd=["xacro", urdf_xacro_path],
        output="screen",
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{"robot_description": robot_description}],
    )

    joint_state_publisher = Node(
        package="joint_state_publisher_gui",
        executable="joint_state_publisher_gui",
        name="joint_state_publisher_gui",
        output="screen",
    )

    rviz = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
    )

    ik_planning_node = Node(
        package="arm_controller",
        executable="ik_planning_node",
        name="ik_planning_node",
        output="screen",
    )

    return LaunchDescription([
        robot_state_publisher,
        joint_state_publisher,
        rviz,
        ik_planning_node,
    ])
