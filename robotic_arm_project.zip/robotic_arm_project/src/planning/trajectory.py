"""
Trajectory generation — produces a smooth, time-parameterized,
collision-checked joint-space path between a start and goal
configuration.

Matches the "Output Stage: Compiling the Action" slide: a quintic
(5th-order) polynomial per joint gives zero velocity/acceleration at
the endpoints (smooth start/stop, like the control_msgs/action/
FollowJointTrajectory message described in the deck), and every
sampled waypoint is checked against the planning scene before the
trajectory is accepted — mirroring MoveIt's discretize-then-validate
approach.
"""

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from scipy.interpolate import CubicSpline

from ..kinematics.forward_kinematics import link_positions
from ..kinematics.inverse_kinematics import solve_ik
from .collision import SphereObstacle, check_link_collisions, check_self_collision


def _quintic_coeffs(q0: float, qf: float, T: float) -> np.ndarray:
    """
    Quintic polynomial coefficients [a0..a5] for q(t) with
    q(0)=q0, q(T)=qf, and zero velocity & acceleration at both ends.
    """
    a0 = q0
    a1 = 0.0
    a2 = 0.0
    a3 = 10 * (qf - q0) / T ** 3
    a4 = -15 * (qf - q0) / T ** 4
    a5 = 6 * (qf - q0) / T ** 5
    return np.array([a0, a1, a2, a3, a4, a5])


def _eval_quintic(coeffs: np.ndarray, t: np.ndarray):
    a0, a1, a2, a3, a4, a5 = coeffs
    pos = a0 + a1 * t + a2 * t ** 2 + a3 * t ** 3 + a4 * t ** 4 + a5 * t ** 5
    vel = a1 + 2 * a2 * t + 3 * a3 * t ** 2 + 4 * a4 * t ** 3 + 5 * a5 * t ** 4
    acc = 2 * a2 + 6 * a3 * t + 12 * a4 * t ** 2 + 20 * a5 * t ** 3
    return pos, vel, acc


@dataclass
class Trajectory:
    t: np.ndarray                 # (K,) time stamps
    q: np.ndarray                 # (K, N) joint positions
    qd: np.ndarray                # (K, N) joint velocities
    qdd: np.ndarray               # (K, N) joint accelerations
    collision_free: bool
    collision_report: List[str] = field(default_factory=list)


def generate_joint_trajectory(
    q_start: np.ndarray,
    q_goal: np.ndarray,
    duration: float = 4.0,
    n_samples: int = 100,
    obstacles: Optional[List[SphereObstacle]] = None,
    link_radius: float = 0.035,
    check_self_collisions: bool = True,
) -> Trajectory:
    """
    Build a quintic joint-space trajectory from q_start to q_goal and
    validate every sampled waypoint against the given obstacles (and
    optionally self-collision).
    """
    n_joints = len(q_start)
    coeffs = [_quintic_coeffs(q_start[i], q_goal[i], duration) for i in range(n_joints)]

    t_samples = np.linspace(0.0, duration, n_samples)
    q_traj = np.zeros((n_samples, n_joints))
    qd_traj = np.zeros((n_samples, n_joints))
    qdd_traj = np.zeros((n_samples, n_joints))

    for i in range(n_joints):
        pos, vel, acc = _eval_quintic(coeffs[i], t_samples)
        q_traj[:, i] = pos
        qd_traj[:, i] = vel
        qdd_traj[:, i] = acc

    collision_report: List[str] = []
    if obstacles:
        for k, q in enumerate(q_traj):
            pts = link_positions(q)
            hits = check_link_collisions(pts, obstacles, link_radius=link_radius)
            if hits:
                collision_report.append(f"[t={t_samples[k]:.2f}s, waypoint {k}] " + "; ".join(hits))

    if check_self_collisions:
        for k, q in enumerate(q_traj):
            pts = link_positions(q)
            hits = check_self_collision(pts, link_radius=link_radius)
            if hits:
                collision_report.append(f"[t={t_samples[k]:.2f}s, waypoint {k}] " + "; ".join(hits))

    return Trajectory(
        t=t_samples, q=q_traj, qd=qd_traj, qdd=qdd_traj,
        collision_free=(len(collision_report) == 0),
        collision_report=collision_report,
    )


def generate_cartesian_guided_trajectory(
    cartesian_waypoints: List[np.ndarray],
    q_seed: np.ndarray,
    duration: float,
    obstacles: Optional[List[SphereObstacle]] = None,
    link_radius: float = 0.035,
    check_self_collisions: bool = True,
) -> Trajectory:
    """
    Follow a polyline of Cartesian (XYZ) waypoints, solving IK at each
    one seeded from the previous joint solution. This keeps the arm's
    configuration continuous along the path (avoiding the sudden
    elbow/wrist flips a pure joint-space quintic can produce between
    two independently-seeded IK solutions near a reach boundary), then
    resamples the resulting joint waypoints onto a smooth, uniformly
    time-parameterized profile with zero end velocity/acceleration.

    This mirrors a Cartesian path planner (e.g. MoveIt's Cartesian
    interpolator) rather than a pure joint-space planner.
    """
    n_wp = len(cartesian_waypoints)
    n_joints = len(q_seed)

    q_prev = q_seed.copy()
    joint_waypoints = np.zeros((n_wp, n_joints))
    for i, xyz in enumerate(cartesian_waypoints):
        result = solve_ik(target_position=xyz, q_init=q_prev)
        joint_waypoints[i] = result.q
        q_prev = result.q

    # Fit ONE smooth cubic spline per joint across all waypoints
    # (clamped to zero velocity only at the very first and last
    # waypoint), rather than stitching independent zero-velocity
    # quintic segments at every intermediate waypoint. This gives a
    # continuous velocity profile (no repeated stop-start "staircase"
    # motion at each via-point) while still producing a
    # FollowJointTrajectory-style smooth position/velocity/acceleration
    # curve overall.
    t_waypoints = np.linspace(0.0, duration, n_wp)
    n_samples = max(n_wp * 15, 150)
    t_samples = np.linspace(0.0, duration, n_samples)

    q_traj = np.zeros((n_samples, n_joints))
    qd_traj = np.zeros((n_samples, n_joints))
    qdd_traj = np.zeros((n_samples, n_joints))
    for j in range(n_joints):
        spline = CubicSpline(t_waypoints, joint_waypoints[:, j], bc_type="clamped")
        q_traj[:, j] = spline(t_samples)
        qd_traj[:, j] = spline(t_samples, 1)
        qdd_traj[:, j] = spline(t_samples, 2)

    collision_report: List[str] = []
    if obstacles:
        for k, q in enumerate(q_traj):
            pts = link_positions(q)
            hits = check_link_collisions(pts, obstacles, link_radius=link_radius)
            if hits:
                collision_report.append(f"[t={t_samples[k]:.2f}s, waypoint {k}] " + "; ".join(hits))
    if check_self_collisions:
        for k, q in enumerate(q_traj):
            pts = link_positions(q)
            hits = check_self_collision(pts, link_radius=link_radius)
            if hits:
                collision_report.append(f"[t={t_samples[k]:.2f}s, waypoint {k}] " + "; ".join(hits))

    return Trajectory(
        t=t_samples, q=q_traj, qd=qd_traj, qdd=qdd_traj,
        collision_free=(len(collision_report) == 0),
        collision_report=collision_report,
    )
