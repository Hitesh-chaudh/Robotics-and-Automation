"""
Collision checking — a lightweight stand-in for the Flexible Collision
Library (FCL) described on the "Collision Avoidance and Scene
Monitoring" slide.

Each arm link is approximated as a capsule (line segment + radius)
between consecutive joint positions returned by forward_kinematics.
Obstacles are approximated as spheres (matching the red cube obstacles
in the "Point A -> Point B" diagram, expanded to bounding spheres).
"""

from dataclasses import dataclass
from typing import List, Tuple

import numpy as np


@dataclass
class SphereObstacle:
    center: np.ndarray
    radius: float
    name: str = "obstacle"


def _point_segment_distance(p: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
    """Minimum distance from point p to segment a-b."""
    ab = b - a
    ab_len2 = np.dot(ab, ab)
    if ab_len2 < 1e-12:
        return float(np.linalg.norm(p - a))
    t = np.clip(np.dot(p - a, ab) / ab_len2, 0.0, 1.0)
    closest = a + t * ab
    return float(np.linalg.norm(p - closest))


def check_link_collisions(
    link_pts: np.ndarray,
    obstacles: List[SphereObstacle],
    link_radius: float = 0.035,
) -> List[str]:
    """
    Check each arm link segment (capsule) against every obstacle sphere.
    Returns a list of human-readable collision descriptions (empty if clear).
    """
    hits = []
    for i in range(len(link_pts) - 1):
        a, b = link_pts[i], link_pts[i + 1]
        for obs in obstacles:
            dist = _point_segment_distance(obs.center, a, b)
            if dist < (link_radius + obs.radius):
                hits.append(
                    f"Link {i}->{i+1} intersects '{obs.name}' "
                    f"(clearance {dist - link_radius - obs.radius:+.4f} m)"
                )
    return hits


def check_self_collision(
    link_pts: np.ndarray,
    link_radius: float = 0.035,
    skip_adjacent: int = 2,
) -> List[str]:
    """
    Very coarse self-collision check: flags any two *non-adjacent* link
    segments whose capsules overlap. Mirrors the "Self-Collision" /
    Allowed Collision Matrix concept from the deck, simplified for a
    teaching-scale demo.
    """
    hits = []
    n = len(link_pts) - 1
    for i in range(n):
        for j in range(i + skip_adjacent, n):
            d = _point_segment_distance(link_pts[i], link_pts[j], link_pts[j + 1])
            if d < 2 * link_radius:
                hits.append(f"Self-collision risk between link {i} and link {j}")
    return hits
