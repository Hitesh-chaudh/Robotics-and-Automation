"""
Forward Kinematics (FK) — deterministic mapping from joint angles (q)
to the end-effector pose T_EE_base (SE(3)).

This is the "Forward Kinematics (Deterministic)" block from the
deck's "Arrow of Causality" slide: always yields exactly one unique
solution, solved by simply chaining DH transforms.
"""

from typing import List
import numpy as np

from .dh_params import DH_PARAMS, NUM_JOINTS, dh_transform


def joint_transforms(q: np.ndarray) -> List[np.ndarray]:
    """
    Return the list of cumulative transforms T_0_1, T_0_2, ..., T_0_6
    (base_link -> each joint frame), used both for FK and for building
    link segments for collision checking.
    """
    assert len(q) == NUM_JOINTS, f"expected {NUM_JOINTS} joint angles, got {len(q)}"

    transforms = []
    T = np.eye(4)
    for (a, alpha, d, offset), theta in zip(DH_PARAMS, q):
        T_i = dh_transform(a, alpha, d, theta + offset)
        T = T @ T_i
        transforms.append(T.copy())
    return transforms


def forward_kinematics(q: np.ndarray) -> np.ndarray:
    """Return the 4x4 homogeneous transform of the end-effector in base frame."""
    return joint_transforms(q)[-1]


def end_effector_position(q: np.ndarray) -> np.ndarray:
    """Convenience: just the XYZ translation of the end-effector."""
    return forward_kinematics(q)[:3, 3]


def link_positions(q: np.ndarray) -> np.ndarray:
    """
    Return an (N+1, 3) array of joint/link origin positions starting at
    the base (0,0,0) through the end-effector. Used for plotting the
    arm and for capsule-based collision checks between consecutive
    joints.
    """
    pts = [np.array([0.0, 0.0, 0.0])]
    for T in joint_transforms(q):
        pts.append(T[:3, 3])
    return np.array(pts)
