"""
Inverse Kinematics (IK) — non-linear, iterative solver that answers
"how much must each joint bend to reach that target XYZ (and
orientation)?" as described on the "Arrow of Causality" and "Solver
Diagnostic Matrix" slides.

This implements a damped least-squares (Levenberg-Marquardt style)
Jacobian solver — the same family as Orocos-KDL / TRAC-IK — using a
numerical Jacobian (finite differences) so no symbolic derivation is
required for an arbitrary DH chain.

Key production concern called out in the deck ("The Local Minima
Trap"): naive joint clamping at a limit can zero out the search
direction and strand the solver. Here we soft-clamp with a repulsive
penalty near limits instead of a hard clamp, which keeps the gradient
informative near the boundary.
"""

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from .dh_params import JOINT_LIMITS, NUM_JOINTS
from .forward_kinematics import forward_kinematics


def _rotation_error(R_target: np.ndarray, R_current: np.ndarray) -> np.ndarray:
    """Axis-angle orientation error vector (small-angle approximation)."""
    R_err = R_target @ R_current.T
    # Skew-symmetric part -> rotation axis * sin(angle)
    v = np.array([
        R_err[2, 1] - R_err[1, 2],
        R_err[0, 2] - R_err[2, 0],
        R_err[1, 0] - R_err[0, 1],
    ]) * 0.5
    return v


def _numerical_jacobian(q: np.ndarray, target_has_orientation: bool,
                         eps: float = 1e-6) -> np.ndarray:
    """6xN (or 3xN) Jacobian via central finite differences of FK."""
    n = len(q)
    rows = 6 if target_has_orientation else 3
    J = np.zeros((rows, n))
    T0 = forward_kinematics(q)
    p0 = T0[:3, 3]
    R0 = T0[:3, :3]

    for i in range(n):
        dq = np.zeros(n)
        dq[i] = eps
        Tp = forward_kinematics(q + dq)
        Tm = forward_kinematics(q - dq)
        J[:3, i] = (Tp[:3, 3] - Tm[:3, 3]) / (2 * eps)
        if target_has_orientation:
            # angular velocity column via log-map approx between +/- eps
            Rp, Rm = Tp[:3, :3], Tm[:3, :3]
            dR = Rp @ Rm.T
            w = np.array([
                dR[2, 1] - dR[1, 2],
                dR[0, 2] - dR[2, 0],
                dR[1, 0] - dR[0, 1],
            ]) / (4 * eps)
            J[3:, i] = w
    return J


@dataclass
class IKResult:
    q: np.ndarray
    success: bool
    iterations: int
    final_error: float
    message: str


def solve_ik(
    target_position: np.ndarray,
    target_orientation: Optional[np.ndarray] = None,
    q_init: Optional[np.ndarray] = None,
    max_iters: int = 200,
    tol: float = 1e-4,
    damping: float = 0.02,
    joint_limits: Tuple[Tuple[float, float], ...] = tuple(JOINT_LIMITS),
    limit_margin: float = 0.05,
) -> IKResult:
    """
    Damped least-squares IK solver.

    Parameters
    ----------
    target_position : (3,) target XYZ in base frame (meters)
    target_orientation : optional (3,3) target rotation matrix. If None,
        only position is solved (3-DOF task, common for "point the
        end-effector at a coordinate" tasks).
    q_init : optional initial joint seed. Defaults to mid-range of
        joint limits (a well-conditioned starting posture).
    """
    n = NUM_JOINTS
    if q_init is None:
        q = np.array([(lo + hi) / 2.0 for lo, hi in joint_limits])
        # perturb slightly off dead-center to avoid singular seeds
        q = q + np.array([0.1, -0.2, 0.3, 0.0, 0.1, 0.0])[:n]
    else:
        q = q_init.copy()

    has_ori = target_orientation is not None
    last_err_norm = np.inf

    for it in range(1, max_iters + 1):
        T = forward_kinematics(q)
        pos_err = target_position - T[:3, 3]
        if has_ori:
            ori_err = _rotation_error(target_orientation, T[:3, :3])
            err = np.concatenate([pos_err, ori_err])
        else:
            err = pos_err

        err_norm = np.linalg.norm(err)
        if err_norm < tol:
            return IKResult(q=q, success=True, iterations=it,
                             final_error=err_norm,
                             message="Converged within tolerance.")

        J = _numerical_jacobian(q, has_ori)

        # Damped least squares step: dq = J^T (J J^T + lambda^2 I)^-1 err
        JJt = J @ J.T
        lam2 = damping ** 2
        dq = J.T @ np.linalg.solve(JJt + lam2 * np.eye(JJt.shape[0]), err)

        # Soft joint-limit repulsion instead of hard clamping, so the
        # gradient direction stays informative near a boundary (avoids
        # "The Local Minima Trap" from the deck).
        for i, (lo, hi) in enumerate(joint_limits):
            if q[i] + dq[i] < lo + limit_margin:
                dq[i] += (lo + limit_margin - (q[i] + dq[i])) * 0.5
            elif q[i] + dq[i] > hi - limit_margin:
                dq[i] -= ((q[i] + dq[i]) - (hi - limit_margin)) * 0.5

        q = q + dq
        # Hard safety clamp only as a last resort (true physical limit)
        q = np.array([np.clip(qi, lo, hi) for qi, (lo, hi) in zip(q, joint_limits)])

        if abs(last_err_norm - err_norm) < 1e-9:
            break
        last_err_norm = err_norm

    T = forward_kinematics(q)
    final_err = np.linalg.norm(target_position - T[:3, 3])
    success = final_err < tol * 10  # relaxed acceptance if we plateaued
    return IKResult(
        q=q, success=success, iterations=it, final_error=final_err,
        message="Converged (relaxed tolerance)." if success else
                "Failed to converge — target may be outside reachable workspace "
                "or near a singularity.",
    )
