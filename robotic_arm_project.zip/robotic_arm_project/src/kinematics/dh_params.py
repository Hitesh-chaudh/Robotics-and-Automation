"""
Denavit-Hartenberg parameters for a generic 6-axis (6-DOF) revolute
industrial manipulator, in the style used on slide "The Arrow of
Causality: Kinematic Formulations" of the training deck.

Standard (non-modified) DH convention:
    T_i = Rot_z(theta_i) * Trans_z(d_i) * Trans_x(a_i) * Rot_x(alpha_i)

Units: meters, radians.
Link lengths are chosen so the arm's reach comfortably covers the
target coordinate used throughout the deck's diagrams:
    X: +450.21 mm, Y: -120.55 mm, Z: +310.00 mm
"""

import numpy as np

# (a, alpha, d, theta_offset) for joints 1..6
DH_PARAMS = [
    # a       alpha        d       theta_offset
    (0.000, np.pi / 2, 0.150, 0.0),   # Joint 1 - base yaw
    (0.425, 0.000, 0.000, 0.0),        # Joint 2 - shoulder
    (0.392, 0.000, 0.000, 0.0),        # Joint 3 - elbow
    (0.000, np.pi / 2, 0.109, 0.0),   # Joint 4 - wrist roll
    (0.000, -np.pi / 2, 0.095, 0.0),  # Joint 5 - wrist pitch
    (0.000, 0.000, 0.082, 0.0),        # Joint 6 - wrist yaw / end-effector
]

# Joint limits in radians (typical +/-170deg style industrial limits,
# tighter on the wrist axes) - referenced by the "Joint Limit Clamping"
# slide, which shows the solver failing near these boundaries.
JOINT_LIMITS = [
    (-2.9671, 2.9671),   # J1  +/-170 deg
    (-1.8326, 1.8326),   # J2  +/-105 deg
    (-2.5307, 2.5307),   # J3  +/-145 deg
    (-3.1416, 3.1416),   # J4  +/-180 deg
    (-2.0944, 2.0944),   # J5  +/-120 deg
    (-3.1416, 3.1416),   # J6  +/-180 deg
]

NUM_JOINTS = len(DH_PARAMS)


def dh_transform(a: float, alpha: float, d: float, theta: float) -> np.ndarray:
    """Homogeneous transform for a single DH link (SE(3), 4x4)."""
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0.0,      sa,       ca,      d],
        [0.0,     0.0,      0.0,    1.0],
    ])
