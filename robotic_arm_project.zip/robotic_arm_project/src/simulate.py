"""
Project 1: Robotic Arm Kinematics & Path Planning — main simulation.

Reproduces the exact scenario from the training deck:
  - A simulated 6-axis robotic arm
  - Moves from Point A to Point B
  - Target end-effector coordinate: X:+450.21mm Y:-120.55mm Z:+310.00mm
  - Two obstacles (the "red cube" boxes in the deck's diagram) sit in
    the workspace between A and B
  - IK solves the required joint angles for the target
  - A smooth quintic trajectory is generated and validated for
    collisions before being "sent" to the (simulated) hardware

Run:
    python3 -m src.simulate
from the project root.
"""

import numpy as np

from .kinematics.forward_kinematics import forward_kinematics, link_positions
from .kinematics.inverse_kinematics import solve_ik
from .kinematics.dh_params import NUM_JOINTS
from .planning.collision import SphereObstacle, check_link_collisions
from .planning.trajectory import generate_joint_trajectory
from .planning.planner import plan_collision_free_path
from .utils.visualization import plot_scene, plot_joint_profiles


def main():
    print("=" * 70)
    print("PROJECT 1: ROBOTIC ARM KINEMATICS & PATH PLANNING")
    print("DecodeLabs Industrial Training Kit — simulated 6-axis arm")
    print("=" * 70)

    # ------------------------------------------------------------------
    # 1. Define Point A (start) and Point B (goal) — mirrors the deck's
    #    workspace diagram with two obstacle boxes between them.
    # ------------------------------------------------------------------
    q_home = np.zeros(NUM_JOINTS)

    point_a = np.array([0.300, 0.250, 0.400])          # Point A (m)
    point_b = np.array([0.45021, -0.12055, 0.31000])   # Point B: target from the deck (mm -> m)

    obstacles = [
        SphereObstacle(center=np.array([0.35941, 0.10343, 0.36440]), radius=0.036, name="obstacle_1"),
        SphereObstacle(center=np.array([0.38869, 0.03120, 0.34686]), radius=0.035, name="obstacle_2"),
    ]
    link_radius = 0.03

    print(f"\nPoint A (start XYZ):  {point_a}")
    print(f"Point B (goal XYZ):   {point_b}")
    print(f"Obstacles in scene:   {[o.name for o in obstacles]}")

    # ------------------------------------------------------------------
    # 2. Inverse Kinematics — solve joint angles for Point A and Point B
    # ------------------------------------------------------------------
    print("\n--- Inverse Kinematics ---")
    ik_a = solve_ik(target_position=point_a, q_init=q_home)
    print(f"IK for Point A: success={ik_a.success}, iters={ik_a.iterations}, "
          f"final_error={ik_a.final_error:.6f} m")
    print(f"  Joint angles (deg): {np.round(np.degrees(ik_a.q), 2)}")

    ik_b = solve_ik(target_position=point_b, q_init=ik_a.q)
    print(f"IK for Point B: success={ik_b.success}, iters={ik_b.iterations}, "
          f"final_error={ik_b.final_error:.6f} m")
    print(f"  Joint angles (deg): {np.round(np.degrees(ik_b.q), 2)}")

    # Sanity check via forward kinematics (round trip)
    fk_check = forward_kinematics(ik_b.q)[:3, 3]
    print(f"  FK(IK(Point B)) = {np.round(fk_check, 5)} "
          f"(target was {np.round(point_b, 5)})")

    if not (ik_a.success and ik_b.success):
        print("\n[WARNING] IK did not fully converge for one or more targets. "
              "Continuing with best-effort solution for demonstration.")

    # ------------------------------------------------------------------
    # 3. Static collision check at start / goal postures
    # ------------------------------------------------------------------
    print("\n--- Static Collision Check ---")
    for label, q in [("Point A pose", ik_a.q), ("Point B pose", ik_b.q)]:
        hits = check_link_collisions(link_positions(q), obstacles, link_radius=link_radius)
        status = "COLLISION" if hits else "clear"
        print(f"{label}: {status}" + (f" -> {hits}" if hits else ""))

    # ------------------------------------------------------------------
    # 4. Trajectory generation (quintic, joint-space) + full-path
    #    collision validation, mirroring MoveIt's discretize-and-verify
    #    approach described in the deck.
    # ------------------------------------------------------------------
    print("\n--- Trajectory Generation (A -> B) ---")
    plan = plan_collision_free_path(
        q_start=ik_a.q, point_start_xyz=point_a,
        point_goal_xyz=point_b, q_goal=ik_b.q,
        obstacles=obstacles, link_radius=link_radius,
    )
    traj = plan.trajectory

    print(f"Planner attempts: {plan.attempts}")
    print(f"Planner message:  {plan.message}")
    print(f"Samples: {len(traj.t)}, Duration: {traj.t[-1]:.1f}s")
    print(f"Trajectory collision-free: {traj.collision_free}")
    if not traj.collision_free:
        print("Collision report (TRAJECTORY ABORT):")
        for line in traj.collision_report[:10]:
            print(f"  - {line}")
        if len(traj.collision_report) > 10:
            print(f"  ... and {len(traj.collision_report) - 10} more waypoint(s)")
    else:
        print("TRAJECTORY ABORT check: none triggered. Path is clear for execution.")

    max_vel = np.max(np.abs(traj.qd))
    max_acc = np.max(np.abs(traj.qdd))
    print(f"Peak joint velocity:     {max_vel:.3f} rad/s")
    print(f"Peak joint acceleration: {max_acc:.3f} rad/s^2")

    # ------------------------------------------------------------------
    # 5. Visualize: 3D scene (RViz-style) + joint profiles (FollowJointTrajectory)
    # ------------------------------------------------------------------
    import os
    os.makedirs("outputs", exist_ok=True)

    scene_path = plot_scene(
        q_start=ik_a.q, q_goal=ik_b.q, obstacles=obstacles,
        trajectory_q=traj.q, save_path="outputs/scene.png",
    )
    profile_path = plot_joint_profiles(
        traj.t, traj.q, traj.qd, traj.qdd, save_path="outputs/joint_profiles.png",
    )

    print(f"\nSaved 3D scene render to:      {scene_path}")
    print(f"Saved joint profile plots to:  {profile_path}")
    print("\n" + "=" * 70)
    print("SIGNAL SUCCESSFULLY DELIVERED: trajectory computed and validated.")
    print("=" * 70)


if __name__ == "__main__":
    main()
