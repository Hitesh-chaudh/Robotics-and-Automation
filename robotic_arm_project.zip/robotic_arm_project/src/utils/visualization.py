"""
Visualization helpers — 3D rendering of the arm + obstacles (a
matplotlib stand-in for RViz's "kinematic intent" view from the
"Split-Reality Mirror" slide) and joint position/velocity/acceleration
profile plots (matching the "Output Stage: Compiling the Action" slide).
"""

from typing import List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from ..kinematics.forward_kinematics import link_positions
from ..planning.collision import SphereObstacle


def _draw_sphere(ax, center, radius, color="red", alpha=0.25):
    u, v = np.mgrid[0:2 * np.pi:20j, 0:np.pi:10j]
    x = center[0] + radius * np.cos(u) * np.sin(v)
    y = center[1] + radius * np.sin(u) * np.sin(v)
    z = center[2] + radius * np.cos(v)
    ax.plot_surface(x, y, z, color=color, alpha=alpha, linewidth=0)


def plot_scene(
    q_start: np.ndarray,
    q_goal: np.ndarray,
    obstacles: List[SphereObstacle],
    trajectory_q: Optional[np.ndarray] = None,
    save_path: str = "outputs/scene.png",
    title: str = "Robotic Arm: Point A -> Point B",
):
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection="3d")

    pts_start = link_positions(q_start)
    pts_goal = link_positions(q_goal)

    ax.plot(pts_start[:, 0], pts_start[:, 1], pts_start[:, 2],
            "o-", color="steelblue", linewidth=4, markersize=6, label="Start pose (Point A)")
    ax.plot(pts_goal[:, 0], pts_goal[:, 1], pts_goal[:, 2],
            "o-", color="crimson", linewidth=4, markersize=6, label="Goal pose (Point B)")

    if trajectory_q is not None:
        ee_path = np.array([link_positions(q)[-1] for q in trajectory_q])
        ax.plot(ee_path[:, 0], ee_path[:, 1], ee_path[:, 2],
                "--", color="darkorange", linewidth=2, label="End-effector trajectory")

        # Faint intermediate poses
        for idx in np.linspace(0, len(trajectory_q) - 1, 6, dtype=int)[1:-1]:
            pts = link_positions(trajectory_q[idx])
            ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], "-", color="gray", alpha=0.35, linewidth=1.5)

    for obs in obstacles:
        _draw_sphere(ax, obs.center, obs.radius)
        ax.text(obs.center[0], obs.center[1], obs.center[2] + obs.radius + 0.02,
                obs.name, color="darkred", fontsize=8, ha="center")

    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.set_title(title)
    ax.legend(loc="upper left", fontsize=8)
    max_range = 0.6
    ax.set_xlim(-0.1, max_range)
    ax.set_ylim(-max_range / 2, max_range / 2)
    ax.set_zlim(0, max_range)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
    return save_path


def plot_joint_profiles(t, q, qd, qdd, save_path: str = "outputs/joint_profiles.png"):
    n_joints = q.shape[1]
    fig, axes = plt.subplots(3, 1, figsize=(9, 9), sharex=True)
    labels = [f"J{i+1}" for i in range(n_joints)]

    for i in range(n_joints):
        axes[0].plot(t, q[:, i], label=labels[i])
        axes[1].plot(t, qd[:, i], label=labels[i])
        axes[2].plot(t, qdd[:, i], label=labels[i])

    axes[0].set_ylabel("Position q(t) [rad]")
    axes[1].set_ylabel("Velocity q'(t) [rad/s]")
    axes[2].set_ylabel("Acceleration q''(t) [rad/s^2]")
    axes[2].set_xlabel("Time (s)")
    for ax in axes:
        ax.grid(alpha=0.3)
    axes[0].legend(loc="upper right", ncol=6, fontsize=7)
    axes[0].set_title("Quintic Joint-Space Trajectory (FollowJointTrajectory equivalent)")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
    return save_path
